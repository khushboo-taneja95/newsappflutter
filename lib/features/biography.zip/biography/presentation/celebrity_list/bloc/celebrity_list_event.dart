part of 'celebrity_list_bloc.dart';

