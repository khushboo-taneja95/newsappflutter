part 'celebrity_list_event.dart';
part 'celebrity_list_state.dart';


