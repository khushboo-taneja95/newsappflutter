part 'celebrity_event.dart';
part 'celebrity_state.dart';

