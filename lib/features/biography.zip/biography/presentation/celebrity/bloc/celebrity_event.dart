part of 'celebrity_bloc.dart';

